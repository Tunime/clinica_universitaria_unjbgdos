<?php $__env->startSection('body'); ?>
    <!-- el contenedor de los contenidos -->
    <div class="col-10 contenedor align-items-stretch d-flex justify-content-center align-items-center">
        <seccion class="container contenedor--contenido">
            <seccion class="row contenedor--contenido_titulo">
                <div class="col">
                    <h3>Lista de usuarios</h3>
                </div>
            </seccion>
            <hr>
            <seccion class="row">
                <div class="col-3">
                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#nuevousuario">+ nuevo usuario</button>
                </div>
                <div class="col-9 d-flex justify-content-end">
                    <form class="form-inline">
                        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                        </form>
                </div>
            </seccion>
            <seccion class="seccion-tabla">
                <table class="table table-striped">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Nick</th>
                        <th scope="col">tipo</th>
                        <th scope="col">Accion</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                    <th scope="row"><?php echo e($usuario->id); ?></th>
                                    <td><?php echo e($usuario->nombre); ?></td>
                                    <td><?php echo e($usuario->email); ?></td>
                                    <td><?php echo e($usuario->tipo_usuario); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-outline-warning">Editar</button>
                                    <?php echo Form::open(['action'=>['UsuarioController@delete',$usuario->id_usuario]]); ?>

                                        <button type="submit" class="btn btn-outline-danger">Eliminar</button>
                                    <?php echo Form::close(); ?>

                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </seccion>
            
        </seccion>
    </div>
    <!--modales-->
    <div id="nuevousuario" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalPopoversLabel" style="display: none;" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalPopoversLabel">Nuevo usuario</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">
              <!--contedor-modal--conteido-->
              <form action="/usuario" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label for="recipient-name" class="col-form-label">Nombre</label>
                  <input type="name" name="nombre"  class="form-control" id="recipient-name">
                </div>
                <div class="form-group">
                    <label for="recipient-name" class="col-form-label">Apellido</label>
                    <input type="lastname" name="apellido" class="form-control" id="recipient-name">
                </div>
                <div class="form-group">
                    <label for="recipient-name" class="col-form-label">Nick</label>
                    <input type="text" name="nick" class="form-control" id="recipient-name">
                </div>
                <div class="form-group">
                    <label for="recipient-name" class="col-form-label">email</label>
                    <input type="email" name="email" class="form-control" id="recipient-name">
                </div>
                <div class="form-group">
                    <label for="recipient-name" class="col-form-label">Contraseña</label>
                    <input type="password" name="contra" class="form-control" id="recipient-name">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlSelect1">tipo usuario</label>
                    <select class="form-control" name="tipo" id="exampleFormControlSelect1">
                      <option>admin</option>
                      <option>invitado</option>
                      <option>secretaria</option>
                    </select>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Gardar</button>
                  </div>
              </form>
            </div>
          </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>