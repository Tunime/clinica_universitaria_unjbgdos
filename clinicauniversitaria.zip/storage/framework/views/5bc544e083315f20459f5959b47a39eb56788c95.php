<?php $__env->startSection('body'); ?>
    <!-- el contenedor de los contenidos -->
    <div class="col-10 contenedor align-items-stretch d-flex justify-content-center align-items-center">
        <seccion class="container contenedor--contenido">
            <seccion class="row contenedor--contenido_titulo">
                <div class="col">
                    <h3>Cambios hechos a Médicos</h3>
                </div>
            </seccion>
            <hr>
            <seccion class="row">
            </seccion>
            <seccion class="container">
                <table class="table table-striped">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre y Apellidos:</th>
                        <th scope="col">Código del médico:</th>
                        <th scope="col">DNI:</th>1
                        <th scope="col">Celular:</th>
                        <th scope="col">Razón del cambio:</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $auditoriamedicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auditoriamedico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($auditoriamedico->id); ?></th>
                                <td><?php echo e($auditoriamedico->nombre); ?><?php echo e($auditoriamedico->apellido); ?></td>
                                <td><?php echo e($auditoriamedico->codigo_medico); ?></td>
                                <td><?php echo e($auditoriamedico->dni_me); ?></td>
                                <td><?php echo e($auditoriamedico->celular); ?></td>
                                <td><?php echo e($auditoriamedico->razon); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($auditoriamedicos->render("pagination::bootstrap-4")); ?>

            </seccion>
            
        </seccion>
    </div>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>