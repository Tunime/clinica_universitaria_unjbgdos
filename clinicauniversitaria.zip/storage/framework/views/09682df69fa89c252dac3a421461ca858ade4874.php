<?php $__env->startSection('body'); ?>
     <!-- el contenedor de los contenidos -->
    <div class="col-10 contenedor align-items-stretch d-flex justify-content-center align-items-center">
        <seccion class="container contenedor--contenido">
            <seccion class="row contenedor--contenido_titulo">
                <div class="col">
                    <h3>Lista de Médicos</h3>
                </div>
            </seccion>
            <hr></hr>
            
            <seccion class="seccion-tabla">
                <form action="<?php echo e(route('medicos.update',$medico->id)); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                <!--formulaio de auditoria-->
                <div style="display: none;">
                    <div class="row">
                        <div class=" col form-group">
                            <label for="recipient-name" class="col-form-label">Nombres:</label>
                            <input value="<?php echo e($medico->nombre); ?>" type="name" name="autnombre"  class="form-control" id="recipient-name" readonly>
                        </div>
                        <div class="col form-group">
                            <label for="recipient-name" class="col-form-label">Apellidos:</label>
                            <input value="<?php echo e($medico->apellido); ?>" type="lastname" name="autapellido" class="form-control" id="recipient-name" readonly>
                        </div>
                    </div>
                    <div class="row">
                        <div class=" col form-group">
                            <label for="recipient-name" class="col-form-label">DNI:</label>
                            <input value="<?php echo e($medico->dni_me); ?>" type="text" name="autdni" class="form-control" maxlength="10" id="recipient-name" readonly>
                        </div>
                        <div class="col form-group">
                            <label for="recipient-name" class="col-form-label">Celular:</label>
                            <input value="<?php echo e($medico->celular); ?>" type="text" name="autcelular" class="form-control" id="recipient-name" readonly>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Fecha de nacimiento:</label>
                        <input value="<?php echo e($medico->fech_nacimiento); ?>" class="form-control" name="autfecha" type="text" maxlength="2" placeholder="Día" readonly>
                    </div>
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Especialidad:</label>
                        <input  value="<?php echo e($medico->especialidad); ?>" type="text" name="autespecialidad" class="form-control" id="recipient-name" readonly>
                    </div>
                    <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Dirección:</label>
                            <input value="<?php echo e($medico->direccion); ?>" type="text" name="autdireccion" class="form-control" id="recipient-name"readonly>
                    </div>
                    <div class="row">
                        <div class="col form-group">
                            <label for="recipient-name" class="col-form-label">Código médico:</label>
                            <input  value="<?php echo e($medico->codigo_medico); ?>" type="text" name="autcodmedico" class="form-control" id="recipient-name"readonly>
                        </div>
                        <div class="col form-group">
                            <label for="exampleFormControlSelect1">Género:</label>
                            <select class="form-control" name="autgenero" id="exampleFormControlSelect1" readonly>
                                <option><?php echo e($medico->genero); ?></option>
                                <option>Hombre</option>
                                <option>Mujer</option>
                                <option>Complicado</option>
                            </select>
                        </div>
                    </div>
                </div>
                <!--fin formulario de auditoria-->
                <div class="row">
                        <div class=" col form-group">
                            <label for="recipient-name" class="col-form-label">Nombres:</label>
                            <input value="<?php echo e($medico->nombre); ?>" type="name" name="nombre"  class="form-control" id="recipient-name">
                        </div>
                        <div class="col form-group">
                            <label for="recipient-name" class="col-form-label">Apellidos:</label>
                            <input value="<?php echo e($medico->apellido); ?>" type="lastname" name="apellido" class="form-control" id="recipient-name">
                        </div>
                    </div>
                    <div class="row">
                        <div class=" col form-group">
                            <label for="recipient-name" class="col-form-label">DNI:</label>
                            <input value="<?php echo e($medico->dni_me); ?>" type="text" name="dni" class="form-control" maxlength="10" id="recipient-name">
                        </div>
                        <div class="col form-group">
                            <label for="recipient-name" class="col-form-label">Celular:</label>
                            <input value="<?php echo e($medico->celular); ?>" type="text" name="celular" class="form-control" id="recipient-name">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col form-group">
                            <label for="recipient-name" class="col-form-label">Fecha de nacimiento:</label>
                            <input value="<?php echo e($medico->fech_nacimiento); ?>" class="form-control" name="fecha" type="text" maxlength="2" placeholder="Día">
                        </div>
                        <div class="col form-group">
                            <label for="recipient-name" class="col-form-label">Especialidad:</label>
                            <input  value="<?php echo e($medico->especialidad); ?>" type="text" name="especialidad" class="form-control" id="recipient-name">
                        </div>
                    </div>
                    <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Dirección:</label>
                            <input value="<?php echo e($medico->direccion); ?>" type="text" name="direccion" class="form-control" id="recipient-name">
                    </div>
                    <div class="row">
                        <div class="col form-group">
                            <label for="recipient-name" class="col-form-label">Código médico:</label>
                            <input  value="<?php echo e($medico->codigo_medico); ?>" type="text" name="codmedico" class="form-control" id="recipient-name">
                        </div>
                        <div class="col form-group">
                            <label for="exampleFormControlSelect1">Género:</label>
                            <select class="form-control" name="genero" id="exampleFormControlSelect1">
                                <option><?php echo e($medico->genero); ?></option>
                                <option>Hombre</option>
                                <option>Mujer</option>
                                <option>Complicado</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlTextarea1">Razón del cambio:</label>
                        <textarea class="form-control" name="autrazon" id="exampleFormControlTextarea1" rows="3" placeholder="Cual es la razón de la modificación..." required></textarea>
                    </div>
                  <div class="modal-footer">
                    <a href="/medicos" type="button" class="btn btn-secondary" data-dismiss="modal">CANCELAR</a>
                    <button type="submit" class="btn btn-primary">GUARDAR</button>
                  </div>
                </form>
            </seccion>
        </seccion>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../template/menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>