<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class atencion extends Model
{
    //la tabla de especialidades
    protected $table = 'atenciones';
    public $timestamps =false;
}
