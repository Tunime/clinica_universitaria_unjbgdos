<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Auditoriapaciente extends Model
{
    //
    protected $table = 'auditoriapacientes';
    public $timestamps =false;
}
