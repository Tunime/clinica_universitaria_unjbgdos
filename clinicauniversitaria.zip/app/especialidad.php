<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class especialidad extends Model
{
    //especificamos la tabla de especialidades
    protected $table = 'especialidades';
    public $timestamps =false;
}
