@extends('template/menu')
@section('body')
    <div class="col-10 contenedor align-items-stretch d-flex justify-content-center align-items-center">
        <seccion class="container contenedor--contenido">

        </seccion>
    </div>
@endsection