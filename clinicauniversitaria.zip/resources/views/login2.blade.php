<!DOCTYPE html>
<html>
<head>
	<title>Login 2.0</title>
	<link rel="stylesheet" type="text/css" href="main.css">
</head>
	<body>
	<div class="login-box">
	<img src="user.png" class="avatar">

	</div>
	</body>
</html>